import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:open_file/open_file.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FireStorageState extends GetxController {
  String _folderPath = "";
  String get folderPath => _folderPath;

  List<Reference> _files = [];
  List<Reference> get files => _files;

  List<Reference> _folders = [];
  List<Reference> get folders => _folders;

  Future<void> getListOfFiles(String path) async {
    List<Reference> tempFiles = [];
    final storageRef = FirebaseStorage.instance.ref(path);
    final listResult = await storageRef.listAll();
    for (var item in listResult.items) {
      tempFiles.add(item);
    }
    _files = tempFiles;
    update();
  }

  void pathsetter(String path) {
    _folderPath = path;
  }

//Future<List<Reference>> testfun(String rootPath) async {
//  List<Reference> tempFiless = [];
//  final storageRef = FirebaseStorage.instance.ref(rootPath);
//  tempFiless.add(storageRef);
//  Future<void> getDirectory(String path) async {
//    final storageRef = FirebaseStorage.instance.ref(path);
//    final listResult = await storageRef.listAll();
//    for (var item in listResult.items) {
//      //tempFiless.add(item);
//      
//      await item.delete();
//      _files.remove(item);
//    }
//    for (var prefix in listResult.prefixes) {
//      print(prefix);
//      //await prefix.delete();
//      //_files.remove(prefix);
//      //tempFiless.add(prefix);
//      getDirectory(prefix.fullPath);
//    }
//  }
//  getDirectory(rootPath);
//  update();
//  return tempFiless;
//}
 Future<void> deleteDirectory(String path) async {
      final storageRef = FirebaseStorage.instance.ref(path);
      final listResult = await storageRef.listAll();
      for (var item in listResult.items) {
        //tempFiless.add(item);
        await item.delete();
        _files.remove(item);
      }
      for (var prefix in listResult.prefixes) {
        print(prefix);
        await prefix.delete();
        _files.remove(prefix);
        //tempFiless.add(prefix);
        deleteDirectory(prefix.fullPath);
      }
    }

  Future<void> getListOfFolders(String path) async {
    List<Reference> tempFolders = [];
    final storageRef = FirebaseStorage.instance.ref(path);
    final listResult = await storageRef.listAll();
    for (var prefix in listResult.prefixes) {
      tempFolders.add(prefix);
    }

    _folders = tempFolders;
    update();
  }

  Future<void> getDirection(String path) async {
    await getListOfFiles(path);
    await getListOfFolders(path);
    update();
  }

  Future<File?> downloadAnyFile(
      Reference ref, BuildContext context, bool message) async {
    //final url = await ref.getDownloadURL();

    String name = ref.name;
    String url = await ref.getDownloadURL();

    try {
      final appStorage = await getApplicationDocumentsDirectory();
      //final file = File('${appStorage.path}/${ref.name}');
      final file = File('${'/storage/emulated/0/Download'}/$name');
      final response = await Dio().get(url,
          options: Options(
              responseType: ResponseType.bytes,
              followRedirects: false,
              receiveTimeout: 0));
      final raf = file.openSync(mode: FileMode.write);
      raf.writeFromSync(response.data);
      if (message) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(ref.name + " downloaded succesfully.")));
      }

      return file;
    } catch (e) {
      print(e);
      return null;
    }
  }

  Future openFile(Reference ref, BuildContext context) async {
    final file = await downloadAnyFile(ref, context, false);
    if (file == null) {
      return;
    }
    OpenFile.open(file.path);
  }

  Future<void> deleteFile(String path, BuildContext context) async {
    print(path);
    final storageRef = FirebaseStorage.instance.ref();
    final deleteRef = storageRef.child(path);
    await deleteRef.delete();
    _files.remove(deleteRef);

    update();
    try {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(path.split("/").last + " deleted succesfully.")));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(path + " deleted succesfully.")));
    }
  }

  Future<void> uploadFile(String destination, BuildContext context) async {
    FilePickerResult? result =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      List<File> files = result.paths.map((path) => File(path!)).toList();
      for (var file in files) {
        final storageRef = FirebaseStorage.instance.ref();
        final uploadRef =
            storageRef.child(destination + "/" + file.path.split("/").last);
        await FirebaseStorage.instance
            .ref(destination + "/" + file.path.split("/").last)
            .putFile(file);

        _files.add(uploadRef);
        try {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content:
                  Text(file.path.split("/").last + " uploaded succesfully.")));
        } catch (e) {}
      }
      update();
    } else {
      // User canceled the picker
    }
  }
  //Future<void> saveToGallery(Reference ref, BuildContext context) async {
  //  final url = await ref.getDownloadURL();
  //  final tempDir = await getTemporaryDirectory();
  //  final path = '${tempDir.path}/${ref.name}';
  //  await Dio().download(url, path);
  //  await GallerySaver.saveImage(path, toDcim: true);
  //  ScaffoldMessenger.of(context).showSnackBar(
  //      SnackBar(content: Text(ref.name + " downloaded succesfully.")));
  //}
}
